export interface ICancellation {
  date: string
  time: string
  amount: number
  name: string
}
