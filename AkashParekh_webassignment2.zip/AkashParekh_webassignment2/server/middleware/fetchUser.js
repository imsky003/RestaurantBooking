

const fetchUser = (req, res, next) => {

    res.render('index', {
        title: 'Hello World'
    })
};
module.exports = fetchUser;
